# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from . import split_rfq_model
from . import res_config_settings
