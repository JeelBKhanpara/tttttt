
from odoo import fields, models


class ResCompanyPurchasesArchive(models.Model):
    _inherit = 'res.company'

    sh_remove_qty = fields.Boolean(
        'Remove Splitted quantity from PO / RFQ', default=True, readonly=False)


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    sh_remove_qty = fields.Boolean(
        'Remove Splitted quantity from PO / RFQ', related="company_id.sh_remove_qty", readonly=False)
