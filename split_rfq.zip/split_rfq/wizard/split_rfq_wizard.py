# -*- coding: utf-8 -*-
# Copyright (C) Softhealer Technologies.

from odoo import models, fields


class SplitRFQWizardLine(models.TransientModel):
    _name = 'sh.split.rfq.wizard.line'
    _description = 'Split RFQ Wizard Line'

    split_line_id = fields.Many2one(
        'sh.split.rfq.wizard', string='Split RFQ Wizard Line')
    qty = fields.Float(string='Quantity')
    product_id = fields.Many2one(
        'product.product', string='Product')


class SplitRFQWizard(models.TransientModel):
    _name = 'sh.split.rfq.wizard'
    _description = 'Split RFQ Wizard'

    purchase_order_id = fields.Many2one(
        'purchase.order', string='Existing RFQ')
    split_line_ids = fields.One2many(
        'sh.split.rfq.wizard.line', 'split_line_id', string='Split RFQ Wizard')
    company_id = fields.Many2one("res.company",
                                 string="Company",
                                 default=lambda self: self.env.company)

    def action_split(self):
        active_id = self.env.context.get('active_id')
        active_po = self.env['purchase.order'].sudo().browse(active_id)

        ticked_lines = active_po.mapped(
            'order_line').filtered(lambda x: x.tick)
        if ticked_lines:
            do_unlink = False
            new_purchase_order_id = False
            for line in active_po.order_line:
                if line.tick:
                    do_unlink = True
            if do_unlink:
                new_purchase_order = active_po.copy()
                new_purchase_order.po_split_id = active_po.id
                new_purchase_order_id = new_purchase_order
                for line in new_purchase_order_id.order_line:
                    if not line.tick:
                        line.unlink()
                    else:
                        if self.split_line_ids:
                            for split in self.split_line_ids:
                                if line.tick and split.product_id == line.product_id:
                                    line.write(
                                        {'product_qty': split.qty})
                                    if self.company_id.sh_remove_qty:
                                        for lines in active_po.order_line:
                                            if lines.tick and split.product_id == lines.product_id:
                                                if not split.qty > lines.product_qty:
                                                    po_line = lines.product_qty - split.qty
                                                    if po_line > 0:
                                                        lines.write(
                                                            {'product_qty': po_line})
                                                    else:

                                                        lines.unlink()
                                                else:
                                                    lines.unlink()
                        line.tick = False

        else:
            new_purchase_order_id = False
            new_purchase_order = active_po.copy()
            new_purchase_order.po_split_id = active_po.id
            new_purchase_order_id = new_purchase_order
            for line in new_purchase_order_id.order_line:
                if self.split_line_ids:
                    for split in self.split_line_ids:
                        if split.product_id == line.product_id:
                            line.write(
                                {'product_qty': split.qty})
                            if self.company_id.sh_remove_qty:
                                for lines in active_po.order_line:
                                    if split.product_id == lines.product_id:
                                        if not split.qty > lines.product_qty:
                                            po_line = lines.product_qty - split.qty
                                            if po_line > 0:
                                                lines.write(
                                                    {'product_qty': po_line})
                                            else:

                                                lines.unlink()
                                        else:
                                            lines.unlink()

        if new_purchase_order_id:
            return{
                'name': 'RFQ',
                'res_model': 'purchase.order',
                'type': 'ir.actions.act_window',
                'view_mode': 'form',
                'res_id': new_purchase_order_id.id,
                'domain': [('id', '=', new_purchase_order_id.id)],
                'target': 'current',
            }
