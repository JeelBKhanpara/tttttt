# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.
{
    "name": "Extract Purchase Order| Extract Request For Quotation | Split Purchase Order| Split Request For Quotation",
    "author": "Softhealer Technologies",
    "website": "http://www.softhealer.com",
    "support": "support@softhealer.com",
    "category": "purchases",
    "license": "OPL-1",
    "summary": """split purchase order lines, extract po module, extract rfq app, split purchase order app, extract request for quotation, split request for quotation odoo""",

    "description": """Split function helpful to split selected order lines and create new RFQ and remove selected lines from the existing order. Extract function helpful to extract purchase order lines without removing from the existing order.""",
    "version": "16.0.1",
    "depends": [
        "purchase"
    ],
    "application": True,
    "data": [
        "security/split_rfq_security_groups.xml",
        "security/ir.model.access.csv",
        "views/res_config_settings_views.xml",
        "views/split_rfq_views.xml",
        "wizard/split_rfq_wizard_views.xml",
    ],
    "images": ["static/description/background.jpg", ],
    "auto_install": False,
    "installable": True,
    "live_test_url": "https://youtu.be/YwYhvjwy74E",
    "price": 15,
    "currency": "EUR"
}
