 # -*- coding: utf-8 -*-
##############################################################################
#    
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-2010 Devintelle Solutions (<http://devintellecs.com/>).
#
##############################################################################

{
    'name': 'Purchase Multi Shipment',
    'version': '16.0.1.2',
    'category': 'Purchases',
    'sequence':1,
    'summary': 'odoo App will split Purchase lines into Multiple Shipment while confirm purchase order,Multi Shipment, Purchase, Confrim Purchase Order, Split purchase , Split Shipment, Multi Purchase shipment, Shipment by Purchase lines, Purchase Multi Shipment',
    'description': """
               odoo App will split Purchase line with Multiple Shipment while confirm purchase order.
               
               Multi Shipment, Purchase, Confrim Purchase Order, Split purchase , Split Shipment, Multi Purchase shipment, Shipment by Purchase lines, 
Purchase Multi Shipment
Odoo Purchase Multi Shipment
Multi shipment 
Odoo multi shipment
Purchase shipment 
Odoo purchase shipment 
App will split purchase lines into multiple shipment while confirm purchase order
Split purchase 
Odoo split purchase
Manage purchase multi shipment 
Odoo manage purchase multi shipment 
Manage purchase shipment 
Odoo manage purchase shipment 
Manage split purchase 
Odoo manage split purchase 
Multi shipment purchase order 
Odoo multi shipment purchase order

 """,
    'author': 'DevIntelle Consulting Service Pvt.Ltd',
    'website': 'http://devintellecs.com/',
    'depends': ['purchase','stock','purchase_stock'],
    'data': [
        'views/purchase_order_views.xml',
    ],
    'demo': [],
    'test': [],
    'css': [],
    'qweb': [],
    'js': [],
    'images': ['images/main_screenshot.png'],
    'installable': True,
    'application': True,
    'auto_install': False,
    'price':19.0,
    'currency':'EUR',
    'pre_init_hook' :'pre_init_check',
}

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
